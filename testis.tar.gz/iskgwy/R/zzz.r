.onLoad <- function(libname, pkgname)
{
  ### Preload to global environment.
  invisible(eval(parse(text = "iskgwy:::init_state()")))

  invisible()
}
