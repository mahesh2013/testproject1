# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Build and Reload Package:  'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

hello <- function() {
  print("Hello, world!")
}

# library(iskgwy)
# iskgwy::client()
t <- 3 * 4
x <- 1:10

# exit()

#library(SparkR)

#sc <- sparkR.init("local[*]")
#3sqlContext <- sparkRSQL.init(sc)

# do something to prove it works
#data(iris)
#df <- createDataFrame(sqlContext, iris)
#head(filter(df, df$Petal_Width > 0.2))
