#' @useDynLib iskgwy
executeR <- function(rInput) {
  # Sys.setenv(DS_HTTP_DEBUG = "1")
  result <- .C("executeR", user="kurapati@us.ibm.com", input=rInput)
  return(result)
}
