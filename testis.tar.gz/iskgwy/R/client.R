#' Interactive R Kernel Gateway Client Launcher
#'
#' Connect to a remote iRKernel.
#'
#' @details
#' The client is a specialized REPL that intercepts commands sent
#' through the R interpreter.  These commands are then sent from the
#' client to and evaluated on the server.
#'
#' To shut down the server and the client, see \code{exit()}.
#'
#' @return
#' Returns \code{TRUE} invisibly on successful exit.
#'
#' @export
client <- function()
{
  reset_state()
  set(prompt, "")
  set(timer, FALSE)
  irkernel_repl_client()

  invisible(TRUE)
}

remoter_readline <- function(input)
{
  if (get.status(continuation))
    symb <- "+ "
  else
    symb <- "> "

  prompt <- paste0(getval(prompt), symb)

  Cc_check <- ".__cantstopwontstop"

  repeat
  {
    check <- tryCatch(read <- readline(prompt=prompt), interrupt=function(.) Cc_check)
    if (check != Cc_check)
      break
    else
    {
      cat("^C\n")
    }
  }

  ### Add to history() and avoid repeatedly appending suffix.
  tmp <- as.character(read)
  suffix <- paste0(" # ", getval(prompt))
  if (!grepl(x = tmp, pattern = paste0(suffix, "$"), perl = TRUE))
    tmp <- paste0(tmp, suffix)
  utils::timestamp(stamp = tmp, prefix = "", suffix = "", quiet = TRUE)

  ret <- c(input, read)
  ret <- remoter_sanitize(inputs=ret)

  return(ret)
}

### TODO use a proper parser...
remoter_sanitize <- function(inputs)
{
  for (i in 1:length(inputs))
  {
    input <- inputs[i]
    if (grepl(x=input, pattern="^(\\s+)?(q|quit)\\(", perl=TRUE))
      inputs[i] <- "exit(client.only=TRUE)"
    else if (grepl(x=input, pattern=".pbdenv") && !getval(debug))
    {
      remoter_client_stop("I can't do that.")
      inputs[i] <- "invisible()"
    }
    else if (grepl(x=input, pattern="^(\\s+)?geterrmessage\\(", perl=TRUE))
      inputs[i] <- getval(client_lasterror)
    else if (grepl(x=input, pattern="^(\\s+)?(\\?\\?|help.search\\(|help.start\\()", perl=TRUE))
    {
      remoter_client_stop("Using help() to obtain help files from the server.")
      inputs[i] <- "invisible()"
    }
    else if (grepl(x=input, pattern="^(\\s+)?debug\\(", perl=TRUE))
    {
      remoter_client_stop("debug mode is currently not supported.")
      inputs[i] <- "invisible()"
    }
    else if (grepl(x=input, pattern="^(\\s+)?warnings\\(", perl=TRUE))
    {
      set.status(shouldwarn, TRUE)
      remoter_show_warnings()
      inputs[i] <- "invisible()"
    }
    else if (input == "")
      inputs[i] <- "invisible()"
    else if (grepl(x=input, pattern="^(\\s+)?(remoter::)?(client|server|relay)\\(", perl=TRUE))
    {
      remoter_client_stop("can not spawn client/server/relay from inside the client")
      inputs[i] <- "invisible()"
    }
  }

  return(inputs)
}

irkernel_client_send <- function(input)
{
  result <- executeR(rInput=input)

  ### Must come last! If client only wants to quit, server doesn't know
  ### about it, and resets the status on receive.socket()
  if (all(grepl(x=input, pattern="^(\\s+)?exit\\(", perl=TRUE)))
    eval(parse(text=input))

  #    remoter_show_errors()
  #    remoter_show_warnings()

  invisible()
  return(result)
}

irkernel_repl_client <- function(env=globalenv())
{
  if (!interactive())
    stop("You can only use the client interactively at this time")

  #test <- remoter_init_client()
  #if (!test) return(FALSE)

  timer <- getval(timer)
  if (timer)
    EVALFUN <- function(expr) capture.output(system.time(expr))
  else
    EVALFUN <- identity

  while (TRUE)
  {
    input <- character(0)
    set.status(continuation, FALSE)
    set.status(visible, FALSE)

    while (TRUE)
    {
      input <- remoter_readline(input=input)

      timing <- EVALFUN({
        irkernel_client_send(input=input)
      })

      if (get.status(continuation)) next

      remoter_repl_printer()

      if (timer)
        cat(paste0(timing[-1], collapse="\n"), "\n")

      ### Should go after all other evals and handlers
      if (get.status(should_exit))
      {
        set.status(remoter_prompt_active, FALSE)
        set.status(should_exit, FALSE)
        return(invisible())
      }

      break
    }
  }

  set.status(remoter_prompt_active, FALSE)
  set.status(should_exit, FALSE)

  return(invisible())
}
