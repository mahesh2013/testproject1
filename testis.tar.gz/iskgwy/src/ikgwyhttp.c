#include "ikgwyhttp.h"
 


void dbgprintf(char *fmt, ...)
{
	char* dbgFlag = getenv("DS_HTTP_DEBUG");
	if(NULL != dbgFlag)
	{
		char buff[1024];
		memset(buff,0,1023);

		va_list argptr;
		va_start(argptr,fmt);
		vsprintf(buff, fmt, argptr);
		va_end(argptr);
		fprintf(stdout, "%s",buff);
	}
}

unsigned long long getMillisecondsSinceEpoch()
{
	struct timeval tv;

	gettimeofday(&tv, NULL);

	unsigned long long millisecondsSinceEpoch =
		(unsigned long long)(tv.tv_sec) * 1000 +
		(unsigned long long)(tv.tv_usec) / 1000;

	return millisecondsSinceEpoch;
}

char* genUserToken(char* pUserId, char* token, char* timestamp)
{
	unsigned char md_value[EVP_MAX_MD_SIZE];
	unsigned int md_len, i;
	EVP_MD_CTX *mdctx;
	const EVP_MD *md;
	char tsbuf[30] ;

	unsigned long long millisecondsSinceEpoch = getMillisecondsSinceEpoch();

	sprintf(tsbuf,"%llu", millisecondsSinceEpoch);

	dbgprintf("buffer:>>%s<<\n", tsbuf);

	char *message = malloc(256);
	memset(message,0,256);

	sprintf(message,"%s:dyNacLoudkillEr:%llu", pUserId, millisecondsSinceEpoch);
	sprintf(timestamp,"%llu",millisecondsSinceEpoch);

	dbgprintf("message:>>%s<<\n", message);
	OpenSSL_add_all_digests();

	md = EVP_sha256();

	if(!md) 
	{
		printf("Unknown message digest \n");
		exit(1);
	}

	mdctx = EVP_MD_CTX_create();
	EVP_DigestInit_ex(mdctx, md, NULL);
	EVP_DigestUpdate(mdctx, message, strlen(message));

	EVP_DigestFinal_ex(mdctx, md_value, &md_len);
	EVP_MD_CTX_destroy(mdctx);

	for(i = 0; i < md_len; i++)
	{
		dbgprintf("%02x",md_value[i]);
		sprintf(token + (i*2),"%02x", md_value[i]);
	}
	dbgprintf("\nDigest is: >>%s<<\n",token);

	/* Call this once before exit. */
	EVP_cleanup();

	return token;
}

char* composeTokenizerUrl(char* user, char* token, char* timestamp)
{
	char *url = malloc(1024);

	char* prefix = getenv("DS_DEBUG_PREFIX"); 
	if(NULL == prefix)
	{
		prefix = "http://dshost:9300/services";
	}
	char* anotherUser = getenv("DS_DEBUG_id");
	if(NULL != anotherUser)
	{
		user = anotherUser;
	}
	char* cmd = "getUserCred";
	char* sp = "cloudantwh_space";
	char* userParam = "__wtiUserInstanceId";
	sprintf(url,"%s/blushiftservices/BluShiftHttp.do?cmd=%s&space_id=%s&%s=%s&token=%s&timestamp=%s",prefix,cmd,sp,userParam, user,token,timestamp);

	return url;
}

void executeR(char** user, char** pRInput)
{
	char *url = malloc(1024);
	char* prefix = "http://bdavm1607.svl.ibm.com:8081/apsrstudio/agent/v1/irkernel/execute";
	sprintf(url, "%s/%s", prefix, *user);

        char *header = malloc(1024);
        sprintf(header, "Content-type: application/json");

        char *postParams = malloc(1024);
        sprintf(postParams, "{\"code\":\"%s\"}", *pRInput);

	string response = makehttp(url,header,postParams);

	if(NULL != response.ptr)
	{
		char resp[256] ;
		memcpy(resp,response.ptr,256);

		dbgprintf("response:%s \n", resp);
		printf("%s \n", resp);
		char *loc = strstr(resp, "\"resultCode\":\"success");
		if(NULL != loc)
		{
		     dbgprintf("success\n");
		}
		else
		{
		     dbgprintf("failed \n");
		}

		free(response.ptr);
	}
	free(url);
	free(header);
	free(postParams);
}

void getCurrentBLUUserCredential(char** pUserName, char** pPassword)
{
	char* user = getCurrUserName();
	char* pass = NULL;

	char token[256];
	char timestamp[128];
		
	genUserToken(user,token, timestamp);


	char* url = composeTokenizerUrl(user,token,timestamp);

	string response = makehttp(url,NULL,NULL);



	if(NULL != response.ptr)
	{
		char resp[256] ;
		memcpy(resp,response.ptr,256);

		dbgprintf("response:%s \n", resp);
		char *loc = strstr(resp, "\"resultCode\":\"success");
		if(NULL != loc)
		{
			/* success */
			char * pStr = "\"password\":\"";
			char* pwdQ = strstr(response.ptr,pStr);
			if(NULL != pwdQ)
			{
				int plen = strlen(pStr);
				char* endQ = strstr(pwdQ + plen , "\"");
				if(NULL != endQ)
				{
					*endQ = 0;
				}
				pass = (pwdQ + plen);
			}
		}
		else
		{
				dbgprintf("failed to get credentials for %s\n",user);
		}

		free(response.ptr);
	}
	free(url);

	if(NULL == pass)
	{
		pass = "";
		user = ""; // return user as empty as well so defaults can be picked up, say with ODBC
	}
	dbgprintf("returning:%s,%s \n", user, pass);
	*pUserName = user;
	*pPassword = pass;
}

char* getCurrUserName()
{
	struct passwd *p = getpwuid(getuid());
	return p->pw_name;
}

void init_string(string *s) 
{
	s->len = 0;
	s->ptr = malloc(s->len+1);
	if (s->ptr == NULL) 
	{
		fprintf(stderr, "malloc() failed\n");
		exit(EXIT_FAILURE);
	}
	s->ptr[0] = '\0';
}

size_t writefunc(void *ptr, size_t size, size_t nmemb, string *s)
{
	size_t new_len = s->len + size*nmemb;
	s->ptr = realloc(s->ptr, new_len+1);
	if (s->ptr == NULL) 
	{
		fprintf(stderr, "realloc() failed\n");
		exit(EXIT_FAILURE);
	}
	memcpy(s->ptr+s->len, ptr, size*nmemb);
	s->ptr[new_len] = '\0';
	s->len = new_len;

	return size*nmemb;
}

string makehttp(char* url, char* headerArgs, char* postParams)
{
	CURL *curl;
	struct curl_slist *headers=NULL; // init to NULL is important 
	CURLcode res;
 
	char* dbgFlag = getenv("DS_HTTP_DEBUG");
	curl_global_init(CURL_GLOBAL_DEFAULT);

	string response;
	init_string(&response);

	curl = curl_easy_init();
	if(curl) 
	{
	 
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
	 
		curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);

		curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 10L);

		curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);

		if(NULL != headerArgs)
		{
			if(NULL != dbgFlag)
			{
				printf("headers is: %s\n", headerArgs);
			}
			headers = curl_slist_append(headers, headerArgs);
			curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
		}
	 
		if(NULL != postParams)
		{
			if(NULL != dbgFlag)
			{
				printf("post data is: %s\n", postParams);
			}
			curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postParams);
		}

		if(NULL != dbgFlag)
		{
			curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
		}

		curl_easy_setopt(curl, CURLOPT_URL, url);

		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writefunc);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
			
		/* Perform the request, res will get the return code */ 
		res = curl_easy_perform(curl);

		/* Check for errors */ 
		if(res != CURLE_OK)
		{
		  fprintf(stderr, "curl_easy_perform() failed: %s\n",
				  curl_easy_strerror(res));
		}
	 
		/* always cleanup */ 
		curl_easy_cleanup(curl);

		 /* free the headers */ 
		if(NULL != headers)
		{
			 curl_slist_free_all(headers);
		}
	}
 
  curl_global_cleanup();
 
  return response;
}
