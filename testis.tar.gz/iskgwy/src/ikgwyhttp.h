#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <pwd.h>
#include <unistd.h>
#include <sys/time.h>
#include <openssl/evp.h>
#include <curl/curl.h>
 
typedef struct 
{
	char *ptr;
	size_t len;
} string;

char* getCurrUserName();
char* genUserToken(char* pUserId, char* token, char* timestamp);
string makehttp(char* url, char* headerArgs, char* postParams);
